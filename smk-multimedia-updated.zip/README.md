# SMK Multimedia
Website e-learning berbasis GitHub Pages untuk SMK Multimedia.

## Fitur
- **PPDB:** Pendaftaran siswa dan guru secara online
- **Perpustakaan:** Manajemen buku, anggota, dan admin
- **E-learning:** Kursus online untuk siswa dan guru
- **Web Sekolah:** Berita dan informasi sekolah

## Cara Menjalankan
1. Fork repository ini atau download sebagai ZIP.
2. Upload ke GitHub dan aktifkan **GitHub Pages** di pengaturan repository.
3. Akses website melalui link GitHub Pages Anda.

## Kontribusi
Silakan fork dan kirim pull request untuk perbaikan atau penambahan fitur.
